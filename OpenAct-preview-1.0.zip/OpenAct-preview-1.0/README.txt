OpenAct 1.0 (public preview)
The free script editor for stage and screen.

WHAT IT DOES
- Sixteen formats: screenplay, TV (one-hour drama, single-camera and multi-camera comedy, UK studio sitcom, vertical micro-drama), stage play (UK and US),
  musical (UK and US), pantomime, radio drama, audio drama and podcasts, video games (branching dialogue with a branch map, recording line IDs, and Ink,
  Yarn Spinner and recording-sheet export), comics, and treatments.
- Saves real files: PDF (matches the page on screen, fonts inside), Word (a named style for each element; it can keep the PDF's page breaks), Fountain and
  Final Draft. An anonymous copy names no author in the file or its properties.
- Import your own format from a Final Draft or Word template, and find common competition and theatre formats ("Find a format").
- "Ready to submit?" checks a script against where it is going, and shows the source for each rule.
- Works offline. No account. Nothing is sent anywhere.

TWO WAYS TO USE IT
1. Open OpenAct.html (double-click it). It runs in your browser, with no connection.
2. Install it as an app. Put the "app" folder on any web host, or run a small server in it ("python3 -m http.server 8080", then open
   http://localhost:8080 in Chrome or Edge), and choose Install in the address bar. On a phone: Add to Home Screen.

WHERE YOUR SCRIPTS ARE
In your browser's storage, on your device. They go nowhere unless you export them. Clearing site data, using a private window, or opening OpenAct
in a different browser, profile or place starts empty, and OpenAct.html and the installed app each keep their own scripts. Export a PDF or a
Fountain file (plain text) now and then. This preview has no sync and no automatic backup.

TESTED, AND NOT YET TESTED
Tested with automated checks in Chrome on Linux: every format, export, import, accessibility (axe) and offline use, at desktop and phone sizes.
Not yet tried: Safari, Firefox, Edge on Windows, a real phone's on-screen keyboard, Word or Final Draft themselves. Please open an exported file
in the program you will use, and check it, before you send it anywhere important.

KNOWN LIMITS
- No spelling or grammar check yet. A4 and US Letter are the only page sizes.
- Final Draft import and export follow the file format as publicly understood; the indent units on import are unverified. Check the preview.
- Courier Prime has no glyph for some characters (for example music notes, arrows and Cyrillic). OpenAct tells you before a PDF drops them; Word keeps them.
- "Find a format" was checked in November 2026. Organisations change their rules, so read the current ones before you send a script.
- OpenAct is not affiliated with Final Draft, or with any competition, broadcaster, theatre or publisher it names.

LICENCE
Free software: GNU General Public License, version 3 or later (LICENSE). The full source, and how to build it, is in source/. The software and fonts
it contains, with their licences, are in THIRD-PARTY-NOTICES.txt and licenses/. The OpenAct name and logo are not covered by the GPL (see
source/brand/README.md).

CHECK YOUR DOWNLOAD
SHA256SUMS.txt lists a checksum for every file. "sha256sum -c SHA256SUMS.txt" (Linux, or "shasum -a 256 -c" on a Mac) checks them.
